
#  Librairies imported
import sys
from PyQt5 import QtWidgets
from Control import Control

app = QtWidgets.QApplication(sys.argv)
c = Control(app)

sys.exit(app.exec_())
